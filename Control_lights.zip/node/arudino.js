var com = require("serialport");

var express = require('express');
var app = express();

app.configure(function() {

	app.use(express.logger('dev'));
	app.use(express.bodyParser());
});

/* 
	Toggle switch starts 
*/

toggleSwitch = function(request, response) {

	console.log('toggleSwitch');
 	var body = request.body;
 	var switchId = body['switchId'];
	var switchStatus = body['switchStatus'];

	switch(switchId) {

		case '1': {

			if (switchStatus == 'ON') {

				serialPort.write('11');
			}
			else {

				serialPort.write('10');
			}

		}
		break;

		case '2': {

			if (switchStatus == 'ON') {

				serialPort.write('21');
			}
			else {

				serialPort.write('20');
			}

		}
		break;

		case '3': {

			if (switchStatus == 'ON') {

				serialPort.write('31');
			}
			else {

				serialPort.write('30');
			}

		}
		break;


		case '4': {

			if (switchStatus == 'ON') {

				serialPort.write('41');
			}
			else {

				serialPort.write('40');
			}

		}
		break;
	}

	response.send('OK');

};

app.post('/toggleSwitch', toggleSwitch);

/*  
	Toggle Switch 
*/

var serialPort = new com.SerialPort("/dev/tty.usbmodem1411", {

    baudrate: 9600,
    parser: com.parsers.readline('\r\n')
  });

serialPort.on('open',function() {
  console.log('Port open');
});

serialPort.on('data', function(data) {

  console.log('serial data from arudino '+ data);
});

app.listen(4000);




