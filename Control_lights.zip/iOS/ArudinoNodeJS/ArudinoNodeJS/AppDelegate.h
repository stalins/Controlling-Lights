//
//  AppDelegate.h
//  ArudinoNodeJS
//
//  Created by Stalin Subramani on 19/01/14.
//  Copyright (c) 2014 ZeeroPush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
