//
//  ViewController.m
//  ArudinoNodeJS
//
//  Created by Stalin Subramani on 19/01/14.
//  Copyright (c) 2014 ZeeroPush. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    ios.layer.cornerRadius = ios.frame.size.height / 2.0;
    nodejs.layer.cornerRadius = nodejs.frame.size.height / 2.0;
    arudino.layer.cornerRadius = arudino.frame.size.height / 2.0;
    
    ios.clipsToBounds = arudino.clipsToBounds = arudino.clipsToBounds = YES;
    
}

- (IBAction)realy1:(UISwitch*)sender {
    
    [self toggleSwitch:sender.isOn relayId:@"1"];
}

- (IBAction)relay2:(UISwitch*)sender {
    
    [self toggleSwitch:sender.isOn relayId:@"2"];

}

- (IBAction)relay3:(UISwitch*)sender {
    
    [self toggleSwitch:sender.isOn relayId:@"3"];

}

- (IBAction)relay4:(UISwitch*)sender {
    
    [self toggleSwitch:sender.isOn relayId:@"4"];

}


-(void) toggleSwitch:(BOOL) state  relayId:(NSString*) relayId{
    
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@:4000/toggleSwitch", @"192.168.1.7"]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:url];
    [request setHTTPMethod:@"POST"];
    
    NSString *body = [NSString stringWithFormat:@"switchId=%@&switchStatus=%@",relayId, state?@"ON":@"OFF"];
    NSData* bodyData = [body dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPBody:bodyData];
    
    NSLog(@"%@", body);
    
//    [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    [NSURLConnection sendAsynchronousRequest:request queue:nil completionHandler:nil];
    
    state = !state;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
    
    
}

@end
