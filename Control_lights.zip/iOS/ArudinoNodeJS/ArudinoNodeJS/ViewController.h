//
//  ViewController.h
//  ArudinoNodeJS
//
//  Created by Stalin Subramani on 19/01/14.
//  Copyright (c) 2014 ZeeroPush. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UILabel *ios, *arudino, *nodejs;
}

@property (strong) IBOutlet UIButton *toggleSwitch;

- (IBAction)realy1:(id)sender;
- (IBAction)relay2:(id)sender;
- (IBAction)relay3:(id)sender;
- (IBAction)relay4:(id)sender;

@end
